(function() {
  'use strict';
  
  console.log('正在初始化Lua语法分析桥接层...');
  
  // 初始化统计信息
  const parserStats = {
    parseCount: 0,
    successCount: 0,
    errorCount: 0,
    lastParseTime: 0
  };
  
  // 1. 初始化Lua虚拟机
  let lua = null;
  let luaVM = null;
  
  try {
    // 检查是否已经加载了fengari
    if (typeof require !== 'undefined') {
      lua = require('fengari');
      luaVM = new lua.VM();
      console.log('Lua虚拟机初始化成功');
    } else {
      throw new Error('找不到Lua虚拟机运行时');
    }
  } catch (error) {
    console.error('Lua虚拟机初始化失败:', error);
    // 提供降级方案：即使没有Lua解析器也能运行基本功能
    window.parseLuaCode = function(code) {
      parserStats.parseCount++;
      parserStats.errorCount++;
      
      return {
        success: false,
        error: 'Lua解析器未正确初始化',
        issues: [{
          type: 'error',
          message: 'Lua解析引擎不可用',
          line: 1,
          column: 1
        }],
        output: '❌ 错误：Lua解析引擎初始化失败\n请确保fengari.js已正确加载',
        identifiers: []
      };
    };
    return;
  }
  
  // 2. 加载Lua解析器代码（这个变量会在外部被替换）
  const parserLuaCode = `##LUA_PARSER_CODE##`;
  
  try {
    // 执行Lua解析器代码
    const loadResult = luaVM.doString(parserLuaCode);
    console.log('Lua解析器代码加载完成');
  } catch (loadError) {
    console.error('加载Lua解析器失败:', loadError);
  }
  
  // 3. 定义主要的分析函数
  function analyzeLuaCode(luaSource) {
    parserStats.parseCount++;
    const startTime = performance.now();
    
    try {
      // 这里调用Lua解析器进行实际分析
      // 注意：这里需要根据您具体Lua解析器的API进行调整
      const analysisResult = luaVM.doString(`
        local luaparser = require("lua")
        local source = [===[${luaSource}]===]
        
        -- 尝试解析代码
        local success, ast_or_error = luaparser.parse_lua(source)
        
        if success then
          -- 解析成功，返回AST和一些基本信息
          return {
            success = true,
            ast = ast_or_error,
            issues = {},
            identifiers = extract_identifiers(ast_or_error)
          }
        else
          -- 解析失败，返回错误信息
          return {
            success = false,
            error = ast_or_error,
            issues = {
              { type = "error", message = ast_or_error, line = 1, column = 1 }
            }
          }
        end
        
        -- 辅助函数：从AST提取标识符
        function extract_identifiers(node)
          local identifiers = {}
          if not node then return identifiers end
          
          -- 这里需要根据您AST的实际结构来编写提取逻辑
          -- 这是一个简化的示例
          local function traverse(n)
            if type(n) == "table" then
              if n.type == "Identifier" and n.name then
                table.insert(identifiers, n.name)
              end
              
              for _, child in pairs(n) do
                if type(child) == "table" then
                  traverse(child)
                end
              end
            end
          end
          
          traverse(node)
          return identifiers
        end
      `);
      
      const endTime = performance.now();
      parserStats.lastParseTime = endTime - startTime;
      
      // 处理分析结果
      if (analysisResult && analysisResult.success === false) {
        parserStats.errorCount++;
        return {
          success: false,
          error: analysisResult.error || '解析失败',
          issues: analysisResult.issues || [],
          output: `❌ 解析失败\n错误: ${analysisResult.error || '未知错误'}`,
          identifiers: [],
          parseTime: parserStats.lastParseTime
        };
      } else {
        parserStats.successCount++;
        
        // 基础语法检查（即使解析成功也要检查常见问题）
        const issues = [];
        const lines = luaSource.split('\n');
        
        // 检查1：未闭合的字符串
        let singleQuoteCount = 0;
        let doubleQuoteCount = 0;
        let inMultiLineString = false;
        
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          
          // 检查字符串引号
          for (let j = 0; j < line.length; j++) {
            const char = line[j];
            const prevChar = j > 0 ? line[j-1] : '';
            
            if (!inMultiLineString) {
              if (char === "'" && prevChar !== '\\') singleQuoteCount++;
              if (char === '"' && prevChar !== '\\') doubleQuoteCount++;
              if (char === '[' && line.substring(j, j+2) === '[') {
                inMultiLineString = true;
                j++; // 跳过下一个字符
              }
            } else if (char === ']' && line.substring(j, j+2) === ']') {
              inMultiLineString = false;
              j++; // 跳过下一个字符
            }
          }
          
          // 检查常见语法模式
          if (line.includes(' end') && !line.includes(' then')) {
            // 检查是否有未匹配的end
          }
          
          // 检查明显错误（示例）
          if (line.includes('== =')) {
            issues.push({
              type: 'error',
              message: '操作符 == 和 = 之间缺少空格或格式错误',
              line: i + 1,
              column: line.indexOf('== =') + 1
            });
          }
        }
        
        // 检查引号是否成对
        if (singleQuoteCount % 2 !== 0) {
          issues.push({
            type: 'error',
            message: "字符串中的单引号 ' 不匹配",
            line: 1,
            column: 1
          });
        }
        
        if (doubleQuoteCount % 2 !== 0) {
          issues.push({
            type: 'error',
            message: '字符串中的双引号 " 不匹配',
            line: 1,
            column: 1
          });
        }
        
        // 构建最终结果
        const result = {
          success: true,
          ast: analysisResult?.ast || {},
          issues: issues,
          identifiers: analysisResult?.identifiers || [],
          output: `✅ 分析成功\n` +
                 `代码长度: ${luaSource.length} 字符\n` +
                 `行数: ${lines.length}\n` +
                 `解析时间: ${parserStats.lastParseTime.toFixed(2)}ms\n` +
                 (issues.length > 0 ? `发现 ${issues.length} 个潜在问题\n` : '未发现语法问题\n'),
          parseTime: parserStats.lastParseTime
        };
        
        return result;
      }
      
    } catch (error) {
      parserStats.errorCount++;
      const endTime = performance.now();
      parserStats.lastParseTime = endTime - startTime;
      
      console.error('Lua分析过程中发生错误:', error);
      
      return {
        success: false,
        error: error.toString(),
        issues: [{
          type: 'error',
          message: `运行时错误: ${error.message || error}`,
          line: 1,
          column: 1
        }],
        output: `❌ 分析过程中发生异常\n错误: ${error.message || error}\n栈: ${error.stack || '无'}`,
        identifiers: [],
        parseTime: parserStats.lastParseTime
      };
    }
  }
  
  // 4. 将函数暴露给全局作用域
  window.parseLuaCode = analyzeLuaCode;
  
  // 5. 暴露统计信息获取函数
  window.getParserStats = function() {
    return {
      ...parserStats,
      successRate: parserStats.parseCount > 0 
        ? (parserStats.successCount / parserStats.parseCount * 100).toFixed(1) 
        : 0
    };
  };
  
  // 6. 暴露一个简单的测试函数
  window.testParser = function() {
    const testCases = [
      { code: 'print("Hello")', expected: true },
      { code: 'local x = 1 + 2 * 3', expected: true },
      { code: 'function test() end', expected: true }
    ];
    
    const results = testCases.map(test => {
      const result = analyzeLuaCode(test.code);
      return {
        code: test.code.substring(0, 20) + '...',
        expected: test.expected,
        actual: result.success,
        match: test.expected === result.success
      };
    });
    
    return {
      allPassed: results.every(r => r.match),
      results: results,
      stats: parserStats
    };
  };
  
  console.log('Lua语法分析桥接层初始化完成');
  console.log('可用函数: parseLuaCode(code), getParserStats(), testParser()');
  
})();