import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_js/flutter_js.dart';

class Lua解析服务 {
  static final Lua解析服务 _实例 = Lua解析服务._内部构造();
  factory Lua解析服务() => _实例;
  Lua解析服务._内部构造();

  late Javascript运行时 _js运行时;
  bool _已初始化 = false;
  final Completer<void> _初始化完成器 = Completer<void>();

  Future<void> 初始化() async {
    if (_已初始化) return _初始化完成器.future;
    
    try {
      _js运行时 = getJavascriptRuntime();
      
      // 1. 加载 Fengari (Lua虚拟机)
      String fengari源码 = await rootBundle.loadString('assets/lua/fengari.js');
      final fengari结果 = _js运行时.evaluate(fengari源码);
      if (fengari结果.isError) {
        throw Exception('加载Fengari失败: ${fengari结果.stringResult}');
      }

      // 2. 加载桥接脚本
      String 桥接脚本 = await rootBundle.loadString('assets/lua/lua_grammar.js');
      final 桥接结果 = _js运行时.evaluate(桥接脚本);
      if (桥接结果.isError) {
        throw Exception('加载桥接脚本失败: ${桥接结果.stringResult}');
      }

      // 3. 测试解析器是否工作
      final 测试结果 = await _执行JS代码('''
        try {
          const 测试代码 = "print('你好，Lua')";
          const 结果 = window.parseLuaCode(测试代码);
          JSON.stringify({ 
            成功: true, 
            测试: '解析器初始化成功',
            解析器就绪: true 
          });
        } catch(e) {
          JSON.stringify({ 
            成功: false, 
            错误: '测试失败: ' + e.toString() 
          });
        }
      ''');

      final 测试数据 = jsonDecode(测试结果);
      if (测试数据['成功'] != true) {
        throw Exception('解析器测试失败: ${测试数据['错误']}');
      }

      _已初始化 = true;
      _初始化完成器.complete();
      
      print('Lua解析服务初始化成功');
    } catch (e) {
      _初始化完成器.completeError(e);
      rethrow;
    }
  }

  Future<String> _执行JS代码(String js代码) async {
    if (!_已初始化) {
      await _初始化完成器.future;
    }
    
    final 结果 = _js运行时.evaluate(js代码);
    if (结果.isError) {
      throw Exception('JS执行错误: ${结果.stringResult}');
    }
    return 结果.stringResult;
  }

  Future<Map<String, dynamic>> 解析代码(String lua源代码) async {
    try {
      // 转义Lua代码中的特殊字符，防止破坏JS字符串
      final 转义后的代码 = _转义Lua代码(lua源代码);
      
      final js代码 = '''
        try {
          const 结果 = window.parseLuaCode(\`$转义后的代码\`);
          if (结果 && typeof 结果 === 'object') {
            return JSON.stringify(结果);
          } else {
            return JSON.stringify({ 
              成功: false, 
              错误: '解析器返回了无效的结果格式' 
            });
          }
        } catch(e) {
          console.error('解析错误:', e);
          return JSON.stringify({ 
            成功: false, 
            错误: '解析过程中发生异常: ' + e.toString(),
            堆栈: e.堆栈 
          });
        }
      ''';

      final json结果 = await _执行JS代码(js代码);
      final 结果数据 = jsonDecode(json结果);
      
      // 确保返回统一的格式
      return {
        '成功': 结果数据['success'] ?? false,
        '抽象语法树': 结果数据['ast'],
        '问题': 结果数据['issues'] ?? [],
        '输出': 结果数据['output'] ?? '',
        '标识符列表': 结果数据['identifiers'] ?? [],
        '错误': 结果数据['error'],
        '时间戳': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      return {
        '成功': false,
        '错误': '解析服务异常: $e',
        '问题': [{
          '类型': '错误',
          '信息': '解析服务异常: $e',
          '行号': 1,
          '列号': 1
        }],
        '输出': '❌ 解析过程中发生严重错误\n$e',
        '时间戳': DateTime.now().toIso8601String(),
      };
    }
  }

  String _转义Lua代码(String 代码) {
    // 转义反引号、美元符号等可能破坏JS模板字符串的字符
    return 代码
        .replaceAll(r'`', r'\`')  // 转义反引号
        .replaceAll(r'\', r'\\')  // 转义反斜杠
        .replaceAll(r'$', r'\$')  // 转义美元符号
        .replaceAll(r'${', r'\${'); // 转义模板变量开始标记
  }

  // 新增：代码格式化功能
  Future<String> 格式化代码(String lua源代码) async {
    try {
      final js代码 = '''
        try {
          // 调用Lua解析器的格式化功能
          const 格式化后的代码 = window.formatLuaCode ? window.formatLuaCode(\`${_转义Lua代码(lua源代码)}\`) : \`${_转义Lua代码(lua源代码)}\`;
          return JSON.stringify({ 成功: true, 格式化后的代码: 格式化后的代码 });
        } catch(e) {
          return JSON.stringify({ 成功: false, 错误: e.toString() });
        }
      ''';
      
      final 结果 = await _执行JS代码(js代码);
      final 数据 = jsonDecode(结果);
      
      if (数据['成功'] == true) {
        return 数据['格式化后的代码'] ?? lua源代码;
      }
      return lua源代码;
    } catch (e) {
      return lua源代码;
    }
  }

  // 获取分析统计信息
  Future<Map<String, dynamic>> 获取分析统计() async {
    final js代码 = '''
      try {
        const 统计 = window.getParserStats ? window.getParserStats() : {
          解析次数: 0,
          成功次数: 0,
          错误次数: 0
        };
        return JSON.stringify({ 成功: true, 统计: 统计 });
      } catch(e) {
        return JSON.stringify({ 成功: false, 错误: e.toString() });
      }
    ''';
    
    final 结果 = await _执行JS代码(js代码);
    return jsonDecode(结果);
  }

  // 清理资源
  void 释放() {
    try {
      _js运行时.dispose();
      _已初始化 = false;
    } catch (e) {
      print('清理资源时发生错误: $e');
    }
  }
}