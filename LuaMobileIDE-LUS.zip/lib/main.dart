import 'package:flutter/material.dart';
import 'ui/editor_screen.dart';

void main() {
  runApp(const LuaMobileIDEApp());
}

class LuaMobileIDEApp extends StatelessWidget {
  const LuaMobileIDEApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lua移动IDE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const EditorScreen(),
    );
  }
}