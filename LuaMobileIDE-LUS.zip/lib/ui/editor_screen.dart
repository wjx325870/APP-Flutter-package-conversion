import 'package:flutter/material.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  _EditorScreenState createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  String _code = '''-- 欢迎使用Lua移动IDE
function hello()
  print("Hello, Lua!")
end

hello()''';
  
  String _result = "就绪。输入Lua代码并点击分析按钮。";
  bool _isAnalyzing = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset(
              'assets/icons/app_logo_small.png',
              width: 32,
              height: 32,
              errorBuilder: (context, error, stackTrace) {
                return const Icon(Icons.code);
              },
            ),
            const SizedBox(width: 12),
            const Text(
              'Lua移动IDE',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ],
        ),
        backgroundColor: Colors.blueGrey[900],
        actions: [
          IconButton(
            icon: Image.asset(
              'assets/images/buttons/btn_settings.png',
              width: 24,
              height: 24,
              errorBuilder: (context, error, stackTrace) {
                return const Icon(Icons.settings, color: Colors.white);
              },
            ),
            onPressed: () {
              _showSettingsDialog();
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/backgrounds/pattern_bg.png'),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.05),
              BlendMode.dstATop,
            ),
          ),
        ),
        child: Column(
          children: [
            // 工具栏
            _buildToolbar(),
            
            // 主编辑区
            Expanded(
              child: Row(
                children: [
                  // 代码编辑器
                  _buildCodeEditor(),
                  
                  // 结果面板
                  _buildResultPanel(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToolbar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      color: Colors.grey[900],
      child: Row(
        children: [
          _buildIconButton(
            icon: 'assets/images/buttons/btn_analyze.png',
            label: _isAnalyzing ? '分析中...' : '分析代码',
            onPressed: _analyzeCode,
            color: Colors.green,
          ),
          const SizedBox(width: 8),
          _buildIconButton(
            icon: 'assets/images/buttons/btn_save.png',
            label: '保存',
            onPressed: _saveCode,
            color: Colors.blue,
          ),
          const SizedBox(width: 8),
          _buildIconButton(
            icon: 'assets/images/buttons/btn_clear.png',
            label: '清空',
            onPressed: _clearCode,
            color: Colors.orange,
          ),
          const SizedBox(width: 8),
          _buildIconButton(
            icon: 'assets/images/buttons/btn_example.png',
            label: '示例',
            onPressed: _loadExample,
            color: Colors.purple,
          ),
          const Spacer(),
          Text(
            '${_code.length} 字符',
            style: const TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildIconButton({
    required String icon,
    required String label,
    required VoidCallback onPressed,
    Color color = Colors.blue,
  }) {
    return ElevatedButton.icon(
      icon: Image.asset(
        icon,
        width: 20,
        height: 20,
        errorBuilder: (context, error, stackTrace) {
          return const Icon(Icons.error_outline, size: 20);
        },
      ),
      label: Text(label),
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
    );
  }

  Widget _buildCodeEditor() {
    return Expanded(
      flex: 3,
      child: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Container(
            color: const Color(0xFF282a36),
            padding: const EdgeInsets.all(16),
            child: SingleChildScrollView(
              child: TextField(
                maxLines: null,
                controller: TextEditingController(text: _code),
                onChanged: (value) => _code = value,
                style: const TextStyle(
                  fontFamily: 'Monospace',
                  fontSize: 14,
                  color: Colors.white,
                  height: 1.5,
                ),
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  hintText: '输入Lua代码...',
                  hintStyle: TextStyle(color: Colors.grey),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResultPanel() {
    return Expanded(
      flex: 2,
      child: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: DefaultTabController(
            length: 2,
            child: Column(
              children: [
                Container(
                  color: Colors.grey[900],
                  child: const TabBar(
                    labelColor: Colors.white,
                    unselectedLabelColor: Colors.grey,
                    indicatorColor: Colors.green,
                    tabs: [
                      Tab(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.analytics, size: 18),
                            SizedBox(width: 6),
                            Text('分析结果'),
                          ],
                        ),
                      ),
                      Tab(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.terminal, size: 18),
                            SizedBox(width: 6),
                            Text('控制台输出'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    children: [
                      // 分析结果标签页
                      Container(
                        color: Colors.grey[900],
                        padding: const EdgeInsets.all(16),
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildResultItem(
                                icon: 'assets/images/ui_elements/success_icon.png',
                                color: Colors.green,
                                title: '语法检查',
                                content: '✅ 无语法错误',
                              ),
                              const SizedBox(height: 12),
                              _buildResultItem(
                                icon: 'assets/images/ui_elements/info_icon.png',
                                color: Colors.blue,
                                title: '代码统计',
                                content: '📊 共 ${_code.split('\n').length} 行，${_code.length} 字符',
                              ),
                            ],
                          ),
                        ),
                      ),
                      // 控制台输出标签页
                      Container(
                        color: Colors.black,
                        padding: const EdgeInsets.all(16),
                        child: SingleChildScrollView(
                          child: Text(
                            _result,
                            style: const TextStyle(
                              fontFamily: 'Monospace',
                              fontSize: 13,
                              color: Colors.lightGreen,
                              height: 1.5,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResultItem({
    required String icon,
    required Color color,
    required String title,
    required String content,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[800],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.asset(
            icon,
            width: 24,
            height: 24,
            errorBuilder: (context, error, stackTrace) {
              return Icon(Icons.circle, color: color, size: 24);
            },
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),