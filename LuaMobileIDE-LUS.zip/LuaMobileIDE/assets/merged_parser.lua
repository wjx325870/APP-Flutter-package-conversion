-- Lua语法解析器 - 基于纯Lua实现
-- 专为移动设备优化的轻量级解析器
-- 版本: 1.0.0

local M = {}

-- 词法分析器
local Lexer = {}
Lexer.__index = Lexer

function Lexer.new(source)
    local self = setmetatable({}, Lexer)
    self.source = source
    self.position = 1
    self.line = 1
    self.column = 1
    self.tokens = {}
    self.keywords = {
        'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for',
        'function', 'goto', 'if', 'in', 'local', 'nil', 'not', 'or',
        'repeat', 'return', 'then', 'true', 'until', 'while'
    }
    self.operators = {
        '+', '-', '*', '/', '%', '^', '#',
        '==', '~=', '<=', '>=', '<', '>', '=',
        '(', ')', '{', '}', '[', ']',
        ';', ':', ',', '.', '..', '...'
    }
    return self
end

function Lexer:skipWhitespace()
    while self.position <= #self.source do
        local char = self.source:sub(self.position, self.position)
        if char == ' ' or char == '\t' then
            self.position = self.position + 1
            self.column = self.column + 1
        elseif char == '\n' then
            self.position = self.position + 1
            self.line = self.line + 1
            self.column = 1
        elseif char == '\r' then
            self.position = self.position + 1
            if self.source:sub(self.position, self.position) == '\n' then
                self.position = self.position + 1
            end
            self.line = self.line + 1
            self.column = 1
        else
            break
        end
    end
end

function Lexer:nextChar()
    if self.position > #self.source then
        return nil
    end
    return self.source:sub(self.position, self.position)
end

function Lexer:peekChar(n)
    n = n or 1
    if self.position + n - 1 > #self.source then
        return nil
    end
    return self.source:sub(self.position, self.position + n - 1)
end

function Lexer:consumeChar()
    local char = self:nextChar()
    if char then
        self.position = self.position + 1
        self.column = self.column + 1
        return char
    end
    return nil
end

function Lexer:readNumber()
    local start = self.position
    local hasDot = false
    
    while self:nextChar() and (self:nextChar():match('%d') or self:nextChar() == '.') do
        if self:nextChar() == '.' then
            if hasDot then break end
            hasDot = true
        end
        self:consumeChar()
    end
    
    -- 科学计数法
    local nextChar = self:nextChar()
    if nextChar and (nextChar == 'e' or nextChar == 'E') then
        self:consumeChar()
        local sign = self:nextChar()
        if sign and (sign == '+' or sign == '-') then
            self:consumeChar()
        end
        while self:nextChar() and self:nextChar():match('%d') do
            self:consumeChar()
        end
    end
    
    local value = self.source:sub(start, self.position - 1)
    return {
        type = 'NUMBER',
        value = value,
        line = self.line,
        column = start
    }
end

function Lexer:readString()
    local quote = self:consumeChar() -- 吃掉起始引号
    local start = self.position
    local value = ""
    
    while self.position <= #self.source do
        local char = self:consumeChar()
        if not char then break end
        
        if char == '\\' then
            -- 转义字符
            local nextChar = self:consumeChar()
            if nextChar == 'n' then
                value = value .. '\n'
            elseif nextChar == 't' then
                value = value .. '\t'
            elseif nextChar == 'r' then
                value = value .. '\r'
            elseif nextChar == '\\' then
                value = value .. '\\'
            elseif nextChar == '"' then
                value = value .. '"'
            elseif nextChar == "'" then
                value = value .. "'"
            else
                value = value .. '\\' .. (nextChar or '')
            end
        elseif char == quote then
            -- 字符串结束
            return {
                type = 'STRING',
                value = value,
                raw = self.source:sub(start - 1, self.position - 1),
                line = self.line,
                column = start - 1
            }
        else
            value = value .. char
        end
    end
    
    -- 字符串未闭合
    return {
        type = 'ERROR',
        value = '未闭合的字符串',
        line = self.line,
        column = start - 1
    }
end

function Lexer:readIdentifier()
    local start = self.position
    local char = self:nextChar()
    
    if char and (char:match('%a') or char == '_') then
        self:consumeChar()
        while self:nextChar() and (self:nextChar():match('%w') or self:nextChar() == '_') do
            self:consumeChar()
        end
    end
    
    local name = self.source:sub(start, self.position - 1)
    
    -- 检查是否为关键字
    for _, keyword in ipairs(self.keywords) do
        if keyword == name then
            return {
                type = 'KEYWORD',
                value = name,
                line = self.line,
                column = start
            }
        end
    end
    
    return {
        type = 'IDENTIFIER',
        value = name,
        line = self.line,
        column = start
    }
end

function Lexer:readLongString()
    local start = self.position
    local openBracket = self:peekChar(2)
    
    if openBracket ~= '[[' and openBracket ~= '=[' then
        return nil
    end
    
    -- 找出等号的数量
    local eqCount = 0
    while self:peekChar(eqCount + 2) and self:peekChar(eqCount + 2):sub(1, 1) == '=' do
        eqCount = eqCount + 1
    end
    
    local openPattern = '[' .. string.rep('=', eqCount) .. '['
    local closePattern = ']' .. string.rep('=', eqCount) .. ']'
    
    self.position = self.position + #openPattern
    
    -- 寻找闭合标记
    local endPos = self.source:find(closePattern, self.position, true)
    if not endPos then
        return {
            type = 'ERROR',
            value = '未闭合的长字符串',
            line = self.line,
            column = start
        }
    end
    
    local content = self.source:sub(self.position, endPos - 1)
    self.position = endPos + #closePattern
    
    return {
        type = 'STRING',
        value = content,
        raw = self.source:sub(start, self.position - 1),
        line = self.line,
        column = start
    }
end

function Lexer:readComment()
    if self:peekChar(2) == '--' then
        local start = self.position
        self.position = self.position + 2
        
        -- 长注释
        if self:nextChar() == '[' then
            local comment = self:readLongString()
            if comment and comment.type == 'STRING' then
                comment.type = 'COMMENT'
                return comment
            end
        end
        
        -- 短注释
        while self.position <= #self.source and self:nextChar() ~= '\n' do
            self.position = self.position + 1
        end
        
        return {
            type = 'COMMENT',
            value = self.source:sub(start + 2, self.position - 1),
            line = self.line,
            column = start
        }
    end
    return nil
end

function Lexer:nextToken()
    self:skipWhitespace()
    
    if self.position > #self.source then
        return {
            type = 'EOF',
            line = self.line,
            column = self.column
        }
    end
    
    -- 检查注释
    local comment = self:readComment()
    if comment then
        return comment
    end
    
    local char = self:nextChar()
    
    -- 数字
    if char:match('%d') then
        return self:readNumber()
    end
    
    -- 字符串
    if char == '"' or char == "'" then
        return self:readString()
    end
    
    -- 长字符串/注释
    if char == '[' then
        local longString = self:readLongString()
        if longString then
            return longString
        end
    end
    
    -- 标识符或关键字
    if char:match('%a') or char == '_' then
        return self:readIdentifier()
    end
    
    -- 操作符
    local twoChar = self:peekChar(2)
    local threeChar = self:peekChar(3)
    
    -- 检查3字符操作符
    if threeChar == '...' or threeChar == '..=' then
        local token = {
            type = 'OPERATOR',
            value = threeChar,
            line = self.line,
            column = self.column
        }
        self.position = self.position + 3
        return token
    end
    
    -- 检查2字符操作符
    local operators2 = {'==', '~=', '<=', '>=', '..', '//'}
    for _, op in ipairs(operators2) do
        if twoChar == op then
            local token = {
                type = 'OPERATOR',
                value = op,
                line = self.line,
                column = self.column
            }
            self.position = self.position + 2
            return token
        end
    end
    
    -- 单字符操作符
    local operators1 = {'+', '-', '*', '/', '%', '^', '#', 
                       '(', ')', '{', '}', '[', ']',
                       ';', ':', ',', '.', '<', '>', '='}
    for _, op in ipairs(operators1) do
        if char == op then
            local token = {
                type = 'OPERATOR',
                value = op,
                line = self.line,
                column = self.column
            }
            self.position = self.position + 1
            return token
        end
    end
    
    -- 未知字符
    local token = {
        type = 'ERROR',
        value = '无法识别的字符: ' .. char,
        line = self.line,
        column = self.column
    }
    self.position = self.position + 1
    return token
end

function Lexer:tokenize()
    self.tokens = {}
    local token
    repeat
        token = self:nextToken()
        table.insert(self.tokens, token)
    until token.type == 'EOF'
    return self.tokens
end

-- 语法分析器
local Parser = {}
Parser.__index = Parser

function Parser.new(tokens)
    local self = setmetatable({}, Parser)
    self.tokens = tokens
    self.position = 1
    self.errors = {}
    return self
end

function Parser:current()
    return self.tokens[self.position]
end

function Parser:peek(n)
    n = n or 1
    return self.tokens[self.position + n]
end

function Parser:consume(type, value)
    local token = self:current()
    if token.type == type and (not value or token.value == value) then
        self.position = self.position + 1
        return token
    end
    
    local errorMsg = string.format('期望 %s%s，但找到 %s',
        type,
        value and (' "' .. value .. '"') or '',
        token.value)
    
    table.insert(self.errors, {
        message = errorMsg,
        line = token.line,
        column = token.column
    })
    
    return nil
end

function Parser:match(type, value)
    local token = self:current()
    if token.type == type and (not value or token.value == value) then
        self.position = self.position + 1
        return true
    end
    return false
end

function Parser:parse()
    local ast = self:parseChunk()
    
    if #self.errors > 0 then
        return nil, self.errors
    end
    
    return ast
end

function Parser:parseChunk()
    local chunk = {
        type = 'Chunk',
        statements = {},
        line = self:current().line,
        column = self:current().column
    }
    
    while self:current().type ~= 'EOF' do
        local stat = self:parseStatement()
        if stat then
            table.insert(chunk.statements, stat)
        end
        
        -- 分号是可选的
        self:match('OPERATOR', ';')
    end
    
    return chunk
end

function Parser:parseStatement()
    local token = self:current()
    
    if token.type == 'KEYWORD' then
        if token.value == 'local' then
            return self:parseLocalStatement()
        elseif token.value == 'if' then
            return self:parseIfStatement()
        elseif token.value == 'while' then
            return self:parseWhileStatement()
        elseif token.value == 'for' then
            return self:parseForStatement()
        elseif token.value == 'function' then
            return self:parseFunctionStatement()
        elseif token.value == 'return' then
            return self:parseReturnStatement()
        elseif token.value == 'break' then
            return self:parseBreakStatement()
        elseif token.value == 'do' then
            self:consume('KEYWORD', 'do')
            local block = self:parseBlock()
            self:consume('KEYWORD', 'end')
            return block
        end
    end
    
    -- 表达式语句
    local expr = self:parseExpression()
    if expr then
        -- 可能是函数调用或赋值
        if self:match('OPERATOR', '=') then
            return self:parseAssignment(expr)
        elseif expr.type == 'CallExpression' then
            return expr
        end
    end
    
    return expr
end

function Parser:parseLocalStatement()
    self:consume('KEYWORD', 'local')
    
    if self:current().value == 'function' then
        -- local function
        self:consume('KEYWORD', 'function')
        local name = self:consume('IDENTIFIER')
        if not name then return nil end
        
        local func = self:parseFunctionBody()
        return {
            type = 'LocalFunction',
            name = name.value,
            func = func,
            line = name.line,
            column = name.column
        }
    end
    
    -- local names = ...
    local names = {}
    repeat
        local name = self:consume('IDENTIFIER')
        if name then
            table.insert(names, name.value)
        end
    until not self:match('OPERATOR', ',')
    
    local init = nil
    if self:match('OPERATOR', '=') then
        init = self:parseExpressionList()
    end
    
    return {
        type = 'LocalDeclaration',
        names = names,
        init = init,
        line = self.tokens[self.position - 1].line,
        column = self.tokens[self.position - 1].column
    }
end

function Parser:parseAssignment(left)
    local lefts = {left}
    
    -- 收集左边的表达式
    while self:match('OPERATOR', ',') do
        local expr = self:parseExpression()
        if expr then
            table.insert(lefts, expr)
        end
    end
    
    self:consume('OPERATOR', '=')
    
    local rights = self:parseExpressionList()
    
    return {
        type = 'Assignment',
        left = lefts,
        right = rights,
        line = left.line,
        column = left.column
    }
end

function Parser:parseIfStatement()
    self:consume('KEYWORD', 'if')
    local condition = self:parseExpression()
    self:consume('KEYWORD', 'then')
    
    local thenBlock = self:parseBlock()
    
    local elseifParts = {}
    while self:match('KEYWORD', 'elseif') do
        local elseifCond = self:parseExpression()
        self:consume('KEYWORD', 'then')
        local elseifBlock = self:parseBlock()
        table.insert(elseifParts, {
            condition = elseifCond,
            block = elseifBlock
        })
    end
    
    local elseBlock = nil
    if self:match('KEYWORD', 'else') then
        elseBlock = self:parseBlock()
    end
    
    self:consume('KEYWORD', 'end')
    
    return {
        type = 'IfStatement',
        condition = condition,
        thenBlock = thenBlock,
        elseifParts = elseifParts,
        elseBlock = elseBlock,
        line = self.tokens[self.position - 1].line,
        column = self.tokens[self.position - 1].column
    }
end

function Parser:parseWhileStatement()
    self:consume('KEYWORD', 'while')
    local condition = self:parseExpression()
    self:consume('KEYWORD', 'do')
    local block = self:parseBlock()
    self:consume('KEYWORD', 'end')
    
    return {
        type = 'WhileStatement',
        condition = condition,
        block = block,
        line = self.tokens[self.position - 1].line,
        column = self.tokens[self.position - 1].column
    }
end

function Parser:parseForStatement()
    self:consume('KEYWORD', 'for')
    local var = self:consume('IDENTIFIER')
    
    if self:match('OPERATOR', '=') then
        -- 数值for循环
        local start = self:parseExpression()
        self:consume('OPERATOR', ',')
        local finish = self:parseExpression()
        local step = nil
        if self:match('OPERATOR', ',') then
            step = self:parseExpression()
        end
        
        self:consume('KEYWORD', 'do')
        local block = self:parseBlock()
        self:consume('KEYWORD', 'end')
        
        return {
            type = 'NumericFor',
            var = var.value,
            start = start,
            finish = finish,
            step = step,
            block = block,
            line = var.line,
            column = var.column
        }
    else
        -- 泛型for循环
        self:consume('KEYWORD', 'in')
        local expressions = self:parseExpressionList()
        self:consume('KEYWORD', 'do')
        local block = self:parseBlock()
        self:consume('KEYWORD', 'end')
        
        return {
            type = 'GenericFor',
            vars = {var.value},
            expressions = expressions,
            block = block,
            line = var.line,
            column = var.column
        }
    end
end

function Parser:parseFunctionStatement()
    self:consume('KEYWORD', 'function')
    
    local name = self:parseExpression()
    local func = self:parseFunctionBody()
    
    return {
        type = 'FunctionDeclaration',
        name = name,
        func = func,
        line = name.line,
        column = name.column
    }
end

function Parser:parseFunctionBody()
    self:consume('OPERATOR', '(')
    
    local params = {}
    if not self:match('OPERATOR', ')') then
        repeat
            local param = self:consume('IDENTIFIER')
            if param then
                table.insert(params, param.value)
            end
        until not self:match('OPERATOR', ',')
        self:consume('OPERATOR', ')')
    end
    
    local block = self:parseBlock()
    self:consume('KEYWORD', 'end')
    
    return {
        type = 'FunctionBody',
        params = params,
        block = block,
        line = self.tokens[self.position - 1].line,
        column = self.tokens[self.position - 1].column
    }
end

function Parser:parseReturnStatement()
    self:consume('KEYWORD', 'return')
    local expressions = nil
    if self:current().type ~= 'KEYWORD' and self:current().type ~= 'EOF' then
        expressions = self:parseExpressionList()
    end
    
    return {
        type = 'ReturnStatement',
        expressions = expressions,
        line = self.tokens[self.position - 1].line,
        column = self.tokens[self.position - 1].column
    }
end

function Parser:parseBreakStatement()
    self:consume('KEYWORD', 'break')
    return {
        type = 'BreakStatement',
        line = self.tokens[self.position - 1].line,
        column = self.tokens[self.position - 1].column
    }
end

function Parser:parseBlock()
    local block = {
        type = 'Block',
        statements = {},
        line = self:current().line,
        column = self:current().column
    }
    
    while self:current().type ~= 'KEYWORD' or 
          (self:current().value ~= 'end' and 
           self:current().value ~= 'else' and 
           self:current().value ~= 'elseif' and 
           self:current().value ~= 'until') do
        if self:current().type == 'EOF' then
            table.insert(self.errors, {
                message = '未闭合的块',
                line = self:current().line,
                column = self:current().column
            })
            break
        end
        
        local stat = self:parseStatement()
        if stat then
            table.insert(block.statements, stat)
        end
        
        self:match('OPERATOR', ';')
    end
    
    return block
end

function Parser:parseExpression()
    return self:parseBinaryExpression(0)
end

function Parser:parseBinaryExpression(minPrecedence)
    local left = self:parseUnaryExpression()
    if not left then return nil end
    
    while true do
        local token = self:current()
        local precedence = self:getOperatorPrecedence(token.value)
        
        if not precedence or precedence <= minPrecedence then
            break
        end
        
        local op = token.value
        self.position = self.position + 1
        
        local right = self:parseBinaryExpression(precedence)
        if not right then break end
        
        left = {
            type = 'BinaryExpression',
            operator = op,
            left = left,
            right = right,
            line = left.line,
            column = left.column
        }
    end
    
    return left
end

function Parser:parseUnaryExpression()
    local token = self:current()
    
    if token.value == 'not' or token.value == '-' or token.value == '#' then
        self.position = self.position + 1
        local expr = self:parseUnaryExpression()
        return {
            type = 'UnaryExpression',
            operator = token.value,
            argument = expr,
            line = token.line,
            column = token.column
        }
    end
    
    return self:parsePrimaryExpression()
end

function Parser:parsePrimaryExpression()
    local expr = self:parseAtomicExpression()
    if not expr then return nil end
    
    while true do
        local token = self:current()
        
        if token.value == '.' then
            self.position = self.position + 1
            local name = self:consume('IDENTIFIER')
            if not name then break end
            
            expr = {
                type = 'MemberExpression',
                object = expr,
                property = name.value,
                computed = false,
                line = expr.line,
                column = expr.column
            }
        elseif token.value == '[' then
            self.position = self.position + 1
            local index = self:parseExpression()
            self:consume('OPERATOR', ']')
            
            expr = {
                type = 'MemberExpression',
                object = expr,
                property = index,
                computed = true,
                line = expr.line,
                column = expr.column
            }
        elseif token.value == '(' then
            self.position = self.position + 1
            local args = self:parseExpressionList()
            self:consume('OPERATOR', ')')
            
            expr = {
                type = 'CallExpression',
                callee = expr,
                arguments = args or {},
                line = expr.line,
                column = expr.column
            }
        elseif token.value == ':' then
            self.position = self.position + 1
            local name = self:consume('IDENTIFIER')
            if not name then break end
            
            expr = {
                type = 'MemberExpression',
                object = expr,
                property = name.value,
                computed = false,
                line = expr.line,
                column = expr.column
            }
            
            -- 方法调用
            if self:match('OPERATOR', '(') then
                local args = self:parseExpressionList()
                self:consume('OPERATOR', ')')
                
                expr = {
                    type = 'CallExpression',
                    callee = expr,
                    arguments = args or {},
                    line = expr.line,
                    column = expr.column
                }
            end
        else
            break
        end
    end
    
    return expr
end

function Parser:parseAtomicExpression()
    local token = self:current()
    
    if token.type == 'IDENTIFIER' then
        self.position = self.position + 1
        return {
            type = 'Identifier',
            name = token.value,
            line = token.line,
            column = token.column
        }
    elseif token.type == 'NUMBER' then
        self.position = self.position + 1
        return {
            type = 'NumberLiteral',
            value = tonumber(token.value) or 0,
            raw = token.value,
            line = token.line,
            column = token.column
        }
    elseif token.type == 'STRING' then
        self.position = self.position + 1
        return {
            type = 'StringLiteral',
            value = token.value,
            raw = token.raw,
            line = token.line,
            column = token.column
        }
    elseif token.value == 'nil' then
        self.position = self.position + 1
        return {
            type = 'NilLiteral',
            value = 'nil',
            line = token.line,
            column = token.column
        }
    elseif token.value == 'true' then
        self.position = self.position + 1
        return {
            type = 'BooleanLiteral',
            value = true,
            line = token.line,
            column = token.column
        }
    elseif token.value == 'false' then
        self.position = self.position + 1
        return {
            type = 'BooleanLiteral',
            value = false,
            line = token.line,
            column = token.column
        }
    elseif token.value == '{' then
        return self:parseTableConstructor()
    elseif token.value == '(' then
        self.position = self.position + 1
        local expr = self:parseExpression()
        self:consume('OPERATOR', ')')
        return expr
    end
    
    return nil
end

function Parser:parseTableConstructor()
    self:consume('OPERATOR', '{')
    
    local fields = {}
    while self:current().value ~= '}' do
        local field = self:parseTableField()
        if field then
            table.insert(fields, field)
        end
        
        if not self:match('OPERATOR', ',') and not self:match('OPERATOR', ';') then
            break
        end
    end
    
    self:consume('OPERATOR', '}')
    
    return {
        type = 'TableConstructor',
        fields = fields,
        line = self.tokens[self.position - 1].line,
        column = self.tokens[self.position - 1].column
    }
end

function Parser:parseTableField()
    local token = self:current()
    
    if token.value == '[' then
        -- 显式键
        self.position = self.position + 1
        local key = self:parseExpression()
        self:consume('OPERATOR', ']')
        self:consume('OPERATOR', '=')
        local value = self:parseExpression()
        
        return {
            type = 'TableKey',
            key = key,
            value = value,
            line = token.line,
            column = token.column
        }
    elseif token.type == 'IDENTIFIER' and self:peek().value == '=' then
        -- 标识符键
        local key = self:consume('IDENTIFIER')
        self:consume('OPERATOR', '=')
        local value = self:parseExpression()
        
        return {
            type = 'TableKeyString',
            key = key.value,
            value = value,
            line = key.line,
            column = key.column
        }
    else
        -- 数组部分
        local value = self:parseExpression()
        return {
            type = 'TableValue',
            value = value,
            line = token.line,
            column = token.column
        }
    end
end

function Parser:parseExpressionList()
    local expressions = {}
    repeat
        local expr = self:parseExpression()
        if expr then
            table.insert(expressions, expr)
        end
    until not self:match('OPERATOR', ',')
    return expressions
end

function Parser:getOperatorPrecedence(op)
    local precedences = {
        ['or'] = 1,
        ['and'] = 2,
        ['<'] = 3, ['>'] = 3, ['<='] = 3, ['>='] = 3, ['~='] = 3, ['=='] = 3,
        ['..'] = 4,
        ['+'] = 5, ['-'] = 5,
        ['*'] = 6, ['/'] = 6, ['//'] = 6, ['%'] = 6,
        ['^'] = 7,
        ['#'] = 8, ['not'] = 8
    }
    return precedences[op]
end

-- 主解析函数
function M.parse_lua(source)
    local lexer = Lexer.new(source)
    local tokens, lexErrors = lexer:tokenize()
    
    local errors = {}
    
    -- 收集词法错误
    for _, token in ipairs(tokens) do
        if token.type == 'ERROR' then
            table.insert(errors, {
                type = 'error',
                message = token.value,
                line = token.line,
                column = token.column
            })
        end
    end
    
    local parser = Parser.new(tokens)
    local ast = parser:parse()
    
    -- 收集语法错误
    for _, err in ipairs(parser.errors) do
        table.insert(errors, {
            type = 'error',
            message = err.message,
            line = err.line,
            column = err.column
        })
    end
    
    if #errors > 0 then
        return false, errors[1].message, errors
    end
    
    return true, ast
end

-- 静态分析函数
function M.analyze_code(source)
    local success, result = M.parse_lua(source)
    
    if not success then
        return {
            success = false,
            errors = {result},
            warnings = {},
            identifiers = {}
        }
    end
    
    -- 提取标识符
    local identifiers = {}
    local function collectIdentifiers(node)
        if not node or type(node) ~= 'table' then return end
        
        if node.type == 'Identifier' and node.name then
            if not identifiers[node.name] then
                identifiers[node.name] = {
                    name = node.name,
                    count = 0,
                    lines = {}
                }
            end
            identifiers[node.name].count = identifiers[node.name].count + 1
            table.insert(identifiers[node.name].lines, node.line)
        end
        
        for k, v in pairs(node) do
            if type(v) == 'table' then
                collectIdentifiers(v)
            end
        end
    end
    
    collectIdentifiers(result)
    
    -- 查找未使用的变量（简单检查）
    local warnings = {}
    for name, info in pairs(identifiers) do
        if info.count == 1 then
            table.insert(warnings, {
                type = 'warning',
                message = string.format("变量 '%s' 只使用了一次", name),
                line = info.lines[1],
                column = 1
            })
        end
    end
    
    return {
        success = true,
        ast = result,
        errors = {},
        warnings = warnings,
        identifiers = identifiers
    }
end

-- 简单的代码格式化建议
function M.format_suggestions(source)
    local lexer = Lexer.new(source)
    local tokens = lexer:tokenize()
    
    local suggestions = {}
    local lineLength = 0
    
    for i, token in ipairs(tokens) do
        if token.type == 'COMMENT' then
            table.insert(suggestions, {
                type = 'info',
                message = '建议保持注释简洁',
                line = token.line,
                column = token.column
            })
        end
        
        -- 检查行长度
        if token.type == 'STRING' and #token.value > 80 then
            table.insert(suggestions, {
                type = 'warning',
                message = '字符串过长，建议拆分',
                line = token.line,
                column = token.column
            })
        end
    end
    
    return suggestions
end

return M