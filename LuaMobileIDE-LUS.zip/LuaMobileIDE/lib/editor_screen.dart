import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:code_text_field/code_text_field.dart';
import 'package:flutter_highlight/themes/dracula.dart';
import 'package:flutter_highlight/themes/monokai-sublime.dart';
import 'package:flutter_highlight/themes/vs.dart';
import 'package:flutter_highlight/flutter_highlight.dart';
import 'package:highlight/languages/lua.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../服务/Lua解析服务.dart';
import '../组件/代码编辑器.dart';
import '../组件/结果面板.dart';
import '../组件/工具栏.dart';

class 编辑器页面 extends StatefulWidget {
  const 编辑器页面({super.key});

  @override
  _编辑器页面状态 createState() => _编辑器页面状态();
}

class _编辑器页面状态 extends State<编辑器页面> {
  // =============== 服务 ===============
  final Lua解析服务 _解析服务 = Lua解析服务();
  
  // =============== 编辑器相关 ===============
  late 代码控制器 _代码控制器;
  final FocusNode _编辑器焦点节点 = FocusNode();
  ScrollController _编辑器滚动控制器 = ScrollController();
  
  // =============== 状态变量 ===============
  List<Map<String, dynamic>> _分析问题 = [];
  bool _正在分析中 = false;
  bool _正在保存中 = false;
  String _控制台输出 = '🟢 Lua移动IDE 已就绪\n';
  
  // =============== 新功能状态 ===============
  bool _自动格式化 = false;
  bool _显示行号 = true;
  bool _自动换行 = false;
  bool _深色模式 = true;
  String _当前主题 = 'dracula';
  double _字体大小 = 14.0;
  int _缩进大小 = 2;
  
  // =============== 历史记录 ===============
  List<Map<String, dynamic>> _代码历史记录 = [];
  int _历史记录索引 = -1;
  Timer? _自动保存定时器;
  
  // =============== 文件管理 ===============
  String? _当前文件路径;
  String? _当前文件名;
  
  // =============== 主题映射 ===============
  final Map<String, Map<String, dynamic>> _主题列表 = {
    'dracula': {
      '主题': draculaTheme,
      '名称': '德古拉',
      '背景颜色': Color(0xFF282a36),
      '预览颜色': Color(0xFF44475a),
    },
    'monokai': {
      '主题': monokaiSublimeTheme,
      '名称': '莫奈凯',
      '背景颜色': Color(0xFF272822),
      '预览颜色': Color(0xFF3E3D32),
    },
    'vs': {
      '主题': vsTheme,
      '名称': 'Visual Studio',
      '背景颜色': Colors.white,
      '预览颜色': Color(0xFFF3F3F3),
    },
  };

  // =============== 代码片段 ===============
  final Map<String, String> _代码片段 = {
    'for循环': '''for i = 1, 10 do
  print("第 " .. i .. " 次循环")
end''',
    
    '函数定义': '''function 问候(名字)
  return "你好, " .. 名字
end

print(问候("世界"))''',
    
    '条件判断': '''local 分数 = 85

if 分数 >= 90 then
  print("优秀")
elseif 分数 >= 60 then
  print("及格")
else
  print("不及格")
end''',
    
    '表格操作': '''-- 创建表格
local 水果列表 = {"苹果", "香蕉", "橙子"}

-- 遍历表格
for i, 水果 in ipairs(水果列表) do
  print(i .. ": " .. 水果)
end

-- 字典式表格
local 人物信息 = {
  姓名 = "小明",
  年龄 = 18,
  城市 = "北京"
}

print(人物信息.姓名 .. "来自" .. 人物信息.城市)''',
    
    '错误处理': '''local function 危险操作()
  local 成功, 结果 = pcall(function()
    -- 可能出错的代码
    return 10 / 0
  end)
  
  if 成功 then
    print("结果: " .. 结果)
  else
    print("错误: " .. 结果)
  end
end

危险操作()''',
  };

  // =============== 初始化 ===============
  @override
  void initState() {
    super.initState();
    _初始化应用();
  }

  Future<void> _初始化应用() async {
    try {
      // 初始化解析服务
      await _解析服务.初始化();
      
      // 加载保存的代码
      await _加载保存的代码();
      
      // 设置自动保存
      _设置自动保存();
      
      setState(() {
        _控制台输出 += '✅ 服务初始化完成\n';
      });
    } catch (e) {
      setState(() {
        _控制台输出 += '❌ 初始化失败: $e\n';
      });
    }
  }

  Future<void> _加载保存的代码() async {
    final 偏好设置 = await SharedPreferences.getInstance();
    final 保存的代码 = 偏好设置.getString('上次代码') ?? _获取默认示例();
    
    _代码控制器 = 代码控制器(
      text: 保存的代码,
      language: lua,
      theme: _主题列表[_当前主题]!['主题'],
      params: 编辑器参数(
        tabSpaces: _缩进大小,
      ),
    );
    
    // 初始化历史记录
    _保存到历史记录();
  }

  String _获取默认示例() {
    return '''-- Lua移动IDE - 代码示例
-- 版本 2.0.0

-- 1. 基础语法
print("欢迎使用Lua移动IDE")

local 姓名 = "开发者"
local 版本 = 2.0
local 是否激活 = true

print("用户: " .. 姓名)
print("版本: " .. 版本)
print("状态: " .. tostring(是否激活))

-- 2. 函数定义
function 阶乘(n)
  if n <= 1 then
    return 1
  else
    return n * 阶乘(n - 1)
  end
end

-- 3. 表格操作
local 学生列表 = {
  {姓名 = "张三", 成绩 = 90},
  {姓名 = "李四", 成绩 = 85},
  {姓名 = "王五", 成绩 = 92}
}

-- 4. 循环遍历
for i, 学生 in ipairs(学生列表) do
  print(string.format("%s的成绩是: %d", 学生.姓名, 学生.成绩))
end

-- 5. 调用函数
local 结果 = 阶乘(5)
print("5的阶乘是: " .. 结果)

-- 6. 错误处理示例
local 成功, 错误信息 = pcall(function()
  print("尝试执行一些代码...")
end)

if not 成功 then
  print("发生错误: " .. 错误信息)
end

print("✅ 示例代码执行完成！")''';
  }

  void _设置自动保存() {
    _自动保存定时器 = Timer.periodic(Duration(seconds: 30), (_) async {
      if (_代码控制器.text.isNotEmpty) {
        await _保存代码到存储();
      }
    });
  }

  // =============== 核心功能 ===============
  
  Future<void> _分析代码() async {
    if (_正在分析中) return;
    
    setState(() {
      _正在分析中 = true;
      _分析问题.clear();
      _控制台输出 = '🔍 正在分析代码...\n';
    });
    
    try {
      final 结果 = await _解析服务.解析代码(_代码控制器.text);
      
      setState(() {
        _正在分析中 = false;
        
        if (结果['成功'] == true) {
          final 问题列表 = List<Map<String, dynamic>>.from(结果['问题'] ?? []);
          final 输出内容 = 结果['输出'] ?? '分析完成';
          
          _分析问题 = 问题列表;
          _控制台输出 = '✅ $输出内容\n\n';
          
          // 自动格式化（如果开启）
          if (_自动格式化 && 问题列表.isEmpty) {
            _格式化代码();
          }
          
          // 显示统计信息
          _显示代码统计();
        } else {
          _控制台输出 = '❌ 分析失败:\n${结果['错误']}\n';
          _分析问题 = [{
            '类型': '错误',
            '信息': 结果['错误'] ?? '未知错误',
            '行号': 1,
            '列号': 1
          }];
        }
      });
    } catch (e) {
      setState(() {
        _正在分析中 = false;
        _控制台输出 = '❌ 发生异常:\n$e\n';
      });
    }
  }

  Future<void> _格式化代码() async {
    try {
      final 格式化后的代码 = await _解析服务.格式化代码(_代码控制器.text);
      
      _保存到历史记录();
      _代码控制器.text = 格式化后的代码;
      
      setState(() {
        _控制台输出 += '🎨 代码格式化完成\n';
      });
    } catch (e) {
      setState(() {
        _控制台输出 += '⚠️ 格式化失败: $e\n';
      });
    }
  }

  // =============== 文件操作 ===============
  
  Future<void> _打开文件() async {
    try {
      FilePickerResult? 选择结果 = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['lua', 'txt'],
        allowMultiple: false,
      );
      
      if (选择结果 != null) {
        final 文件 = 选择结果.files.first;
        final 内容 = String.fromCharCodes(文件.bytes!);
        
        _保存到历史记录();
        _代码控制器.text = 内容;
        _当前文件路径 = 文件.path;
        _当前文件名 = 文件.name;
        
        setState(() {
          _控制台输出 = '📂 已打开文件: ${文件.name}\n';
          _控制台输出 += '📏 文件大小: ${文件.size} 字节\n';
        });
      }
    } catch (e) {
      setState(() {
        _控制台输出 = '❌ 打开文件失败: $e\n';
      });
    }
  }

  Future<void> _保存文件() async {
    if (_正在保存中) return;
    
    setState(() { _正在保存中 = true; });
    
    try {
      if (_当前文件路径 == null) {
        // 保存为新文件
        final 路径 = await FilePicker.platform.saveFile(
          dialogTitle: '保存Lua文件',
          fileName: 'lua_脚本_${DateTime.now().millisecondsSinceEpoch}.lua',
          allowedExtensions: ['lua'],
        );
        
        if (路径 != null) {
          await _保存代码到存储();
          _当前文件路径 = 路径;
          _当前文件名 = 路径.split('/').last;
        }
      }
      
      setState(() {
        _控制台输出 = '💾 文件保存成功\n';
        if (_当前文件名 != null) {
          _控制台输出 += '📄 文件名: $_当前文件名\n';
        }
        _正在保存中 = false;
      });
    } catch (e) {
      setState(() {
        _控制台输出 = '❌ 保存失败: $e\n';
        _正在保存中 = false;
      });
    }
  }

  Future<void> _保存代码到存储() async {
    final 偏好设置 = await SharedPreferences.getInstance();
    await 偏好设置.setString('上次代码', _代码控制器.text);
    await 偏好设置.setString('上次保存时间', DateTime.now().toIso8601String());
  }

  // =============== 历史记录 ===============
  
  void _保存到历史记录() {
    final 当前代码 = _代码控制器.text;
    if (_代码历史记录.isEmpty || _代码历史记录.last['代码'] != 当前代码) {
      _代码历史记录.add({
        '代码': 当前代码,
        '时间': DateTime.now(),
        '长度': 当前代码.length,
        '行数': 当前代码.split('\n').length,
      });
      _历史记录索引 = _代码历史记录.length - 1;
      
      // 限制历史记录数量
      if (_代码历史记录.length > 100) {
        _代码历史记录.removeAt(0);
        _历史记录索引--;
      }
    }
  }

  void _撤销() {
    if (_历史记录索引 > 0) {
      _历史记录索引--;
      _代码控制器.text = _代码历史记录[_历史记录索引]['代码'];
      
      setState(() {
        _控制台输出 += '↩️ 已撤销操作\n';
      });
    }
  }

  void _重做() {
    if (_历史记录索引 < _代码历史记录.length - 1) {
      _历史记录索引++;
      _代码控制器.text = _代码历史记录[_历史记录索引]['代码'];
      
      setState(() {
        _控制台输出 += '↪️ 已重做操作\n';
      });
    }
  }

  // =============== 辅助功能 ===============
  
  void _显示代码统计() {
    final 代码 = _代码控制器.text;
    final 行列表 = 代码.split('\n');
    final 字符数 = 代码.length;
    final 单词数 = 代码.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length;
    final 非空行数 = 行列表.where((line) => line.trim().isNotEmpty).length;
    final 注释行数 = 行列表.where((line) => line.trim().startsWith('--')).length;
    
    setState(() {
      _控制台输出 += '''
📊 代码统计报告：
────────────────
📝 总行数: ${行列表.length} 行
📈 有效代码: $非空行数 行
💬 注释行: $注释行数 行
🔤 总字符: $字符数 个
📖 单词数: $单词数 个
📏 平均行长: ${字符数 / (非空行数 == 0 ? 1 : 非空行数).toStringAsFixed(1)} 字符
────────────────
''';
    });
  }

  void _清空代码() {
    setState(() {
      _代码控制器.text = '';
      _控制台输出 = '🗑️ 编辑器已清空\n';
    });
  }

  void _加载示例() {
    setState(() {
      _代码控制器.text = '''-- Lua高级示例代码

-- 计算阶乘
function 计算阶乘(数字)
  if 数字 <= 1 then
    return 1
  else
    return 数字 * 计算阶乘(数字 - 1)
  end
end

-- 斐波那契数列
function 斐波那契(位置)
  if 位置 <= 2 then
    return 1
  else
    return 斐波那契(位置-1) + 斐波那契(位置-2)
  end
end

-- 测试函数
print("10的阶乘: " .. 计算阶乘(10))
print("第10个斐波那契数: " .. 斐波那契(10))

-- 表格操作示例
local 学生成绩表 = {
  张三 = {语文=90, 数学=85, 英语=88},
  李四 = {语文=78, 数学=92, 英语=85},
  王五 = {语文=88, 数学=79, 英语=94}
}

for 姓名, 成绩 in pairs(学生成绩表) do
  local 平均分 = (成绩.语文 + 成绩.数学 + 成绩.英语) / 3
  print(string.format("%s的平均分: %.1f", 姓名, 平均分))
end''';
      _控制台输出 = '📚 高级示例代码已加载\n';
    });
  }

  void _分享代码() async {
    try {
      await Share.share(
        _代码控制器.text,
        subject: 'Lua代码分享',
      );
      setState(() {
        _控制台输出 += '📤 代码已分享\n';
      });
    } catch (e) {
      setState(() {
        _控制台输出 += '❌ 分享失败: $e\n';
      });
    }
  }

  void _打开Lua教程() async {
    final 链接 = Uri.parse('https://www.lua.org/manual/5.4/');
    if (await canLaunchUrl(链接)) {
      await launchUrl(链接);
    } else {
      setState(() {
        _控制台输出 += '❌ 无法打开教程链接\n';
      });
    }
  }

  void _更改主题(String 主题名称) {
    setState(() {
      _当前主题 = 主题名称;
      _代码控制器.theme = _主题列表[主题名称]!['主题'];
      _控制台输出 += '🎨 已切换到${_主题列表[主题名称]!['名称']}主题\n';
    });
  }

  void _调整字体大小(double 新大小) {
    setState(() {
      _字体大小 = 新大小;
      _控制台输出 += '🔤 字体大小调整为: $新大小\n';
    });
  }

  // =============== 用户界面构建 ===============
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lua移动IDE'),
        backgroundColor: Colors.blueGrey[900],
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _显示设置对话框,
            tooltip: '设置',
          ),
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: _分享代码,
            tooltip: '分享代码',
          ),
          IconButton(
            icon: const Icon(Icons.help_outline),
            onPressed: _打开Lua教程,
            tooltip: 'Lua教程',
          ),
        ],
      ),
      
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blueGrey[900],
              ),
              child: const Text(
                'Lua移动IDE',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.file_open),
              title: const Text('打开文件'),
              onTap: () {
                Navigator.pop(context);
                _打开文件();
              },
            ),
            ListTile(
              leading: const Icon(Icons.save),
              title: const Text('保存文件'),
              onTap: () {
                Navigator.pop(context);
                _保存文件();
              },
            ),
            ListTile(
              leading: const Icon(Icons.history),
              title: const Text('历史记录'),
              onTap: () {
                Navigator.pop(context);
                _显示历史记录对话框();
              },
            ),
            ListTile(
              leading: const Icon(Icons.palette),
              title: const Text('主题设置'),
              onTap: () {
                Navigator.pop(context);
                _显示主题选择对话框();
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.info),
              title: const Text('关于'),
              onTap: () {
                Navigator.pop(context);
                _显示关于对话框();
              },
            ),
          ],
        ),
      ),
      
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.blueGrey.shade800,
              Colors.blueGrey.shade900,
            ],
          ),
        ),
        child: Column(
          children: [
            // 增强工具栏
            _构建增强工具栏(),
            
            // 主编辑区
            Expanded(
              child: Row(
                children: [
                  // 代码编辑器
                  _构建代码编辑器(),
                  
                  // 结果面板
                  _构建结果面板(),
                ],
              ),
            ),
          ],
        ),
      ),
      
      floatingActionButton: FloatingActionButton(
        onPressed: _分析代码,
        backgroundColor: Colors.green,
        child: _正在分析中
            ? const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                strokeWidth: 3,
              )
            : const Icon(Icons.play_arrow, color: Colors.white),
      ),
    );
  }

  Widget _构建增强工具栏() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      color: Colors.grey[900]!.withOpacity(0.8),
      child: Column(
        children: [
          // 第一行：主要功能按钮
          Row(
            children: [
              // 撤销/重做按钮
              IconButton(
                icon: const Icon(Icons.undo, color: Colors.white),
                onPressed: _撤销,
                tooltip: '撤销',
              ),
              IconButton(
                icon: const Icon(Icons.redo, color: Colors.white),
                onPressed: _重做,
                tooltip: '重做',
              ),
              
              const SizedBox(width: 16),
              
              // 主要操作按钮
              _构建图标按钮(
                icon: Icons.play_arrow,
                label: _正在分析中 ? '分析中...' : '分析代码',
                onPressed: _分析代码,
                color: Colors.green,
              ),
              
              const SizedBox(width: 8),
              
              _构建图标按钮(
                icon: Icons.format_align_left,
                label: '格式化',
                onPressed: _格式化代码,
                color: Colors.blue,
              ),
              
              const SizedBox(width: 8),
              
              _构建图标按钮(
                icon: Icons.save,
                label: '保存',
                onPressed: _保存文件,
                color: Colors.purple,
              ),
            ],
          ),
          
          const SizedBox(height: 4),
          
          // 第二行：辅助功能
          Row(
            children: [
              // 主题选择
              DropdownButton<String>(
                value: _当前主题,
                icon: const Icon(Icons.arrow_drop_down, color: Colors.white),
                dropdownColor: Colors.grey[900],
                onChanged: (String? 新值) {
                  if (新值 != null) _更改主题(新值);
                },
                items: _主题列表.keys.map((String 主题) {
                  return DropdownMenuItem<String>(
                    value: 主题,
                    child: Text(
                      '主题: ${_主题列表[主题]!['名称']}',
                      style: const TextStyle(color: Colors.white),
                    ),
                  );
                }).toList(),
              ),
              
              const SizedBox(width: 16),
              
              // 代码片段插入
              DropdownButton<String>(
                value: null,
                hint: const Text(
                  '插入代码片段',
                  style: TextStyle(color: Colors.white),
                ),
                icon: const Icon(Icons.arrow_drop_down, color: Colors.white),
                dropdownColor: Colors.grey[900],
                onChanged: (String? 值) {
                  if (值 != null) _插入代码片段(值);
                },
                items: _代码片段.keys.map((String 片段) {
                  return DropdownMenuItem<String>(
                    value: 片段,
                    child: Text(
                      片段,
                      style: const TextStyle(color: Colors.white),
                    ),
                  );
                }).toList(),
              ),
              
              const Spacer(),
              
              // 显示代码信息
              Text(
                '${_代码控制器.text.length} 字符，${_代码控制器.text.split('\n').length} 行',
                style: const TextStyle(color: Colors.grey),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _构建图标按钮({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    Color color = Colors.blue,
  }) {
    return ElevatedButton.icon(
      icon: Icon(icon, size: 20),
      label: Text(label),
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
    );
  }

  Widget _构建代码编辑器() {
    return Expanded(
      flex: 3,
      child: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Container(
            color: _主题列表[_当前主题]!['背景颜色'],
            child: CodeField(
              controller: _代码控制器,
              focusNode: _编辑器焦点节点,
              textStyle: TextStyle(
                fontFamily: 'Monospace',
                fontSize: _字体大小,
                height: 1.5,
              ),
              lineNumberStyle: const LineNumberStyle(
                margin: 8,
                textStyle: TextStyle(color: Colors.grey),
              ),
              decoration: BoxDecoration(
                color: _主题列表[_当前主题]!['背景颜色'],
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _构建结果面板() {
    return Expanded(
      flex: 2,
      child: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: DefaultTabController(
            length: 2,
            child: Column(
              children: [
                Container(
                  color: Colors.grey[900],
                  child: const TabBar(
                    labelColor: Colors.white,
                    unselectedLabelColor: Colors.grey,
                    indicatorColor: Colors.green,
                    tabs: [
                      Tab(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.analytics, size: 18),
                            SizedBox(width: 6),
                            Text('分析结果'),
                          ],
                        ),
                      ),
                      Tab(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.terminal, size: 18),
                            SizedBox(width: 6),
                            Text('控制台输出'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    children: [
                      // 分析结果标签页
                      _分析问题.isEmpty
                          ? const Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.check_circle,
                                    color: Colors.green,
                                    size: 64,
                                  ),
                                  SizedBox(height: 16),
                                  Text(
                                    '代码检测通过',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    '未发现语法问题',
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                ],
                              ),
                            )
                          : ListView.builder(
                              itemCount: _分析问题.length,
                              itemBuilder: (context, index) {
                                return _构建问题项(_分析问题[index], index);
                              },
                            ),

                      // 控制台输出标签页
                      Container(
                        padding: const EdgeInsets.all(12),
                        color: Colors.black,
                        child: SingleChildScrollView(
                          child: SelectableText(
                            _控制台输出,
                            style: const TextStyle(
                              fontFamily: 'Monospace',
                              fontSize: 13,
                              color: Colors.lightGreen,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _构建问题项(Map<String, dynamic> 问题, int 索引) {
    Color 颜色;
    IconData 图标;
    
    switch (问题['类型']) {
      case '错误':
        颜色 = Colors.red;
        图标 = Icons.error;
        break;
      case '警告':
        颜色 = Colors.orange;
        图标 = Icons.warning;
        break;
      default:
        颜色 = Colors.blue;
        图标 = Icons.info;
    }

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      elevation: 2,
      child: ListTile(
        leading: Icon(图标, color: 颜色),
        title: Text(
          问题['信息'] ?? '未知问题',
          style: TextStyle(color: 颜色, fontWeight: FontWeight.w500),
        ),
        subtitle: 问题['行号'] != null 
            ? Text('第 ${问题['行号']} 行，第 ${问题['列号'] ?? 1} 列')
            : null,
        trailing: 问题['行号'] != null
            ? IconButton(
                icon: const Icon(Icons.arrow_right),
                onPressed: () {
                  _控制台输出 += '已定位到第 ${问题['行号']} 行\n';
                  setState(() {});
                },
              )
            : null,
      ),
    );
  }

  void _插入代码片段(String 片段名称) {
    if (_代码片段.containsKey(片段名称)) {
      final 光标位置 = _代码控制器.selection.base.offset;
      final 当前文本 = _代码控制器.text;
      final 新文本 = 当前文本.substring(0, 光标位置) + 
                  _代码片段[片段名称]! + 
                  当前文本.substring(光标位置);
      
      _保存到历史记录();
      _代码控制器.text = 新文本;
      setState(() {
        _控制台输出 += '📝 已插入: $片段名称\n';
      });
    }
  }

  // =============== 对话框方法 ===============
  
  void _显示设置对话框() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('设置'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SwitchListTile(
                title: const Text('自动格式化'),
                value: _自动格式化,
                onChanged: (bool 值) {
                  setState(() {
                    _自动格式化 = 值;
                    _控制台输出 += _自动格式化 
                        ? '✅ 已开启自动格式化\n'
                        : '⭕ 已关闭自动格式化\n';
                  });
                  Navigator.pop(context);
                },
              ),
              SwitchListTile(
                title: const Text('显示行号'),
                value: _显示行号,
                onChanged: (bool 值) {
                  setState(() {
                    _显示行号 = 值;
                    _控制台输出 += _显示行号 
                        ? '✅ 已显示行号\n'
                        : '⭕ 已隐藏行号\n';
                  });
                  Navigator.pop(context);
                },
              ),
              SwitchListTile(
                title: const Text('自动换行'),
                value: _自动换行,
                onChanged: (bool 值) {
                  setState(() {
                    _自动换行 = 值;
                    _控制台输出 += _自动换行 
                        ? '✅ 已开启自动换行\n'
                        : '⭕ 已关闭自动换行\n';
                  });
                  Navigator.pop(context);
                },
              ),
              const Divider(),
              ListTile(
                title: const Text('字体大小'),
                subtitle: Slider(
                  value: _字体大小,
                  min: 10,
                  max: 24,
                  divisions: 14,
                  label: _字体大小.round().toString(),
                  onChanged: (double 值) {
                    _调整字体大小(值);
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  void _显示主题选择对话框() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('选择主题'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: _主题列表.entries.map((entry) {
              final 主题名称 = entry.key;
              final 主题数据 = entry.value;
              
              return ListTile(
                leading: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: 主题数据['预览颜色'],
                    borderRadius: BorderRadius.circular(6),
                  ),
                ),
                title: Text(主题数据['名称']),
                subtitle: Text(主题名称),
                trailing: _当前主题 == 主题名称
                    ? const Icon(Icons.check, color: Colors.green)
                    : null,
                onTap: () {
                  _更改主题(主题名称);
                  Navigator.pop(context);
                },
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  void _显示历史记录对话框() {
    if (_代码历史记录.isEmpty) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('历史记录'),
          content: const Text('暂无历史记录'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('确定'),
            ),
          ],
        ),
      );
      return;
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('历史记录'),
        content: SizedBox(
          width: double.maxFinite,
          height: 300,
          child: ListView.builder(
            itemCount: _代码历史记录.length,
            itemBuilder: (context, index) {
              final 记录 = _代码历史记录[index];
              final 时间 = 记录['时间'] is DateTime 
                  ? 记录['时间'] 
                  : DateTime.parse(记录['时间']);
              final 是否当前 = index == _历史记录索引;
              
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: 是否当前 ? Colors.blue : Colors.grey,
                  child: Text(
                    '${index + 1}',
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
                title: Text(
                  '${时间.hour}:${时间.minute.toString().padLeft(2, '0')}',
                  style: TextStyle(
                    fontWeight: 是否当前 ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
                subtitle: Text(
                  '${记录['行数']} 行，${记录['长度']} 字符',
                ),
                trailing: 是否当前
                    ? const Icon(Icons.check, color: Colors.green)
                    : null,
                onTap: () {
                  _历史记录索引 = index;
                  _代码控制器.text = 记录['代码'];
                  Navigator.pop(context);
                  setState(() {
                    _控制台输出 += '⏪ 已恢复到历史记录 ${index + 1}\n';
                  });
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
          TextButton(
            onPressed: () {
              _代码历史记录.clear();
              _历史记录索引 = -1;
              Navigator.pop(context);
              setState(() {
                _控制台输出 += '🗑️ 历史记录已清空\n';
              });
            },
            child: const Text('清空历史'),
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
          ),
        ],
      ),
    );
  }

  void _显示关于对话框() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('关于 Lua移动IDE'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '版本: 2.0.0',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              '一个在移动设备上运行的Lua代码编辑器，支持语法分析、代码格式化、错误检测等功能。',
            ),
            SizedBox(height: 8),
            Text(
              '功能特色:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Text('• 实时语法分析'),
            Text('• 代码自动格式化'),
            Text('• 多主题切换'),
            Text('• 代码片段快速插入'),
            Text('• 文件管理功能'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _自动保存定时器?.cancel();
    _代码控制器.dispose();
    _编辑器焦点节点.dispose();
    _编辑器滚动控制器.dispose();
    super.dispose();
  }
}