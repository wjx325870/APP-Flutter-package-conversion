package com.example.lusluadetector

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}